//
//  vibratedevice.m
//  DeviceVibrate
//
//  Created by Zabiullah on 15/08/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

#import "vibratedevice.h"
#import <AudioToolbox/AudioToolbox.h>

@implementation vibratedevice

+(void) vibrateMyDevice
{
    AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
}
@end
