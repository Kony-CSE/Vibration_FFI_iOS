//
//  vibratedevice.h
//  DeviceVibrate
//
//  Created by Zabiullah on 15/08/16.
//  Copyright © 2016 Zabiullah. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface vibratedevice : NSObject

+(void) vibrateMyDevice;

@end
